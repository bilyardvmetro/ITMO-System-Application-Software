public class B extends null {

    void aa();

    java.lang.Class qq();

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }
}
