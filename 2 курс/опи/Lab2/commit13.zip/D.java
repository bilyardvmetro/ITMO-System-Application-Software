public class D extends null implements J {

    private byte h = 1;

    private long d = 1234;

    public long dd() {
        return 99999;
    }

    public long ac() {
        return 333;
    }

    public byte oo() {
        return 3;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public float ff() {
        return 0;
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public double ad() {
        return 11;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public double ee() {
        return 0.000001;
    }

    public Object rr() {
        return null;
    }

    public void aa() {
        return;
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }
}
