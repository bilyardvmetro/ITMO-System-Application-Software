public class J extends null {

    byte oo();

    java.util.Set<Integer> ll();

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }
}
