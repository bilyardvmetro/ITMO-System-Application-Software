public class B extends null {

    void aa();

    java.lang.Class qq();

    public byte oo() {
        return 1;
    }
}
