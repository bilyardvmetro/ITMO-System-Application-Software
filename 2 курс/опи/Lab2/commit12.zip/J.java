public class J extends null {

    byte oo();

    java.util.Set<Integer> ll();
}
