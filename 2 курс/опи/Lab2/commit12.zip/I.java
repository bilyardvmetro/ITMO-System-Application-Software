public class I extends null implements B, J {

    private long c = 4321;

    private long e = 4321;

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public double ee() {
        return 0.000001;
    }

    public void aa() {
        System.out.println("Hello world!");
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public byte oo() {
        return 3;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public String kk() {
        return "No";
    }

    public long dd() {
        return 33;
    }

    public Object rr() {
        return null;
    }

    public int af() {
        return -1;
    }

    public Object pp() {
        return this;
    }

    public float ff() {
        return 0;
    }
}
