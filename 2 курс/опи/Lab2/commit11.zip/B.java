public interface B {

    void aa();

    java.lang.Class qq();
}
