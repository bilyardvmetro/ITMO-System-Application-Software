public interface J {

    byte oo();

    java.util.Set<Integer> ll();
}
