public class I implements B, J {

    private long c = 4321;

    private long e = 4321;

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public double ee() {
        return 0.000001;
    }

    public void aa() {
        System.out.println("Hello world!");
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public byte oo() {
        return 3;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public long dd() {
        return 33;
    }
}
